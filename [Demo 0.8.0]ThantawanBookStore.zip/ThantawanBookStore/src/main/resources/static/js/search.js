function searchRedirect(e) {
    e.preventDefault();

    let searchInput = document.getElementById('searchInput');
    let searchInput2 = document.getElementById('searchInput2');

    if(searchInput && searchInput.value) {
        window.location.href = `SearchBook.html?BookName=${searchInput.value}`;
    }

    if(searchInput2 && searchInput2.value) {
        window.location.href = `SearchBook.html?BookName=${searchInput2.value}`;
    }
}
