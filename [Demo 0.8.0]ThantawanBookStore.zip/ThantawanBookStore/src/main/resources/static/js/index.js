fetch("/book/countBook", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
})
  .then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    return response.text();
  })
  .then((data) => {
    if (data) {
      var jsonData = JSON.parse(data);
      fetch("/book/getRandomBook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          return response.text();
        })
        .then((data) => {
          if (data) {
            var jsonDataContent = JSON.parse(data);
            if (jsonDataContent) {
              // Assuming jsonData is the number of slider-items you want to create
              for (var i = 0; i < jsonData; i++) {
                // Create new slider item elements
                var sliderItem = document.createElement("div");
                sliderItem.className =
                  "slider-item slick-slide slick-current slick-active";

                var bannerContent = document.createElement("div");
                bannerContent.className = "banner-content";
                sliderItem.appendChild(bannerContent);

                var title = document.createElement("h2");
                title.className = "banner-title";
                title.id = "sliderItem" + (i + 1);
                title.textContent = "Life of the Wild";
                bannerContent.appendChild(title);

                var text = document.createElement("p");
                text.id = "sliderInfo" + (i + 1);
                text.textContent =
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit...";
                bannerContent.appendChild(text);

                var btnWrap = document.createElement("div");
                btnWrap.className = "btn-wrap";
                bannerContent.appendChild(btnWrap);

                var link = document.createElement("a");
                link.href =
                  "BookDetail.html?BookID=" + jsonDataContent[i].book.bookID;
                link.className = "btn btn-outline-accent btn-accent-arrow";
                link.innerHTML =
                  'Read More<i class="icon icon-ns-arrow-right"></i>';
                btnWrap.appendChild(link);

                var image = document.createElement("img");
                image.src = "images/main-banner1.jpg";
                image.alt = "banner";
                image.className = "banner-image";
                image.id = "sliderPics" + (i + 1);
                image.style.maxWidth = "413px";
                image.style.maxHeight = "602px";
                sliderItem.appendChild(image);

                // Append the new slider item to the main slider
                var mainSlider = document.querySelector(
                  ".main-slider.pattern-overlay"
                );
                mainSlider.appendChild(sliderItem);
                document.getElementById("sliderItem" + (i + 1)).textContent =
                  jsonDataContent[i].book.bname;
                document.getElementById("sliderInfo" + (i + 1)).textContent =
                  jsonDataContent[i].book.tagline;
                document.getElementById("sliderPics" + (i + 1)).src =
                  "data:image/jpeg;base64," +
                  jsonDataContent[i].pictures[0].picture;
              }
            }
          } else {
            console.log("No data returned from server");
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    } else {
      console.log("No data returned from server");
    }
  })
  .catch((error) => {
    console.error("Error:", error);
  });

fetch("/book/getTopBook", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
})
  .then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    return response.text();
  })
  .then((data) => {
    if (data) {
      var jsonDataContent = JSON.parse(data);
      if (jsonDataContent) {
        document.getElementById("top1title").textContent =
          jsonDataContent[0].book.bname;
        document.getElementById("top1img").src =
          "data:image/jpeg;base64," + jsonDataContent[0].pictures[0].picture;
        document.getElementById("top1price").textContent =
          jsonDataContent[0].book.rentPricePerDay +
          "฿ / 1 day (มัดจำ " +
          jsonDataContent[0].book.securityDeposit +
          "฿)";
        var authors = "";

        for (var j = 0; j < jsonDataContent[0].authors.length; j++) {
          // Add each author to the string, separated by a comma and a space
          authors += jsonDataContent[0].authors[j].author;
          if (j < jsonDataContent[0].authors.length - 1) {
            authors += ", ";
          }
        }
        document.getElementById("top1author").textContent =
          "เขียนโดย: " + authors;
        document.getElementById("top1link").href =
          "BookDetail.html?BookID=" + jsonDataContent[0].book.bookID;
        if (jsonDataContent[0].book.tagline == "") {
          document.getElementById("top1info").textContent = "ไม่มีรายละเอียด";
        } else {
          document.getElementById("top1info").textContent =
            jsonDataContent[0].book.tagline;
        }

        // Loop over the JSON data
        for (let i = 0; i < jsonDataContent.length; i++) {
          // Create a new div element
          let div = document.createElement("div");
          div.className = "col-md-3";

          // Create the product item
          let productItem = document.createElement("div");
          productItem.className = "product-item";
          productItem.style.alignContent = "center";

          // Create the figure
          let figure = document.createElement("figure");
          figure.className = "product-style";
          figure.style.width = "auto";
          figure.style.height = "318px";
          figure.style.alignContent = "center";

          // Create the image
          let img = document.createElement("img");
          img.src =
            "data:image/jpeg;base64," + jsonDataContent[i].pictures[0].picture;
          img.alt = "Books";
          img.className = "product-item";
          img.style.maxWidth = "300px";
          img.style.maxHeight = "318px";

          var a = document.createElement("a");
          a.href = "BookDetail.html?BookID=" + jsonDataContent[i].book.bookID;
          // Create the button
          let button = document.createElement("button");
          button.type = "button";
          button.className = "add-to-cart login-registerpopup";
          button.dataset.productTile = "add-to-cart";
          button.textContent = "Detail";

          // Append the 'button' to the 'a' element
          a.appendChild(button);

          // Append the image and button to the figure
          figure.appendChild(img);
          figure.appendChild(a);

          // Append the figure to the product item
          productItem.appendChild(figure);

          // Create the figcaption
          let figcaption = document.createElement("figcaption");

          // Create the h3
          let h3 = document.createElement("h3");
          h3.textContent = jsonDataContent[i].book.bname;

          var authors = "";

          for (var j = 0; j < jsonDataContent[i].authors.length; j++) {
            // Add each author to the string, separated by a comma and a space
            authors += jsonDataContent[i].authors[j].author;
            if (j < jsonDataContent[i].authors.length - 1) {
              authors += ", ";
            }
          }
          // Create the span
          let span = document.createElement("span");
          span.textContent = authors;

          // Create the price div
          let priceDiv = document.createElement("div");
          priceDiv.className = "item-price";
          priceDiv.textContent =
            jsonDataContent[i].book.rentPricePerDay +
            "฿ / 1 day (มัดจำ " +
            jsonDataContent[i].book.securityDeposit +
            "฿)";

          // Append the h3, span, and price div to the figcaption
          figcaption.appendChild(h3);
          figcaption.appendChild(span);
          figcaption.appendChild(priceDiv);

          // Append the figcaption to the product item
          productItem.appendChild(figcaption);

          // Append the product item to the div
          div.appendChild(productItem);

          let divCopy = div.cloneNode(true);

          // Finally, append the div to the row div
          document.querySelector("#all-genre .row").appendChild(divCopy);

          if (jsonDataContent[i].book.category.cname == "Children's Books") {
            document.querySelector("#ChildrenBooks .row").appendChild(div);
          } else if (jsonDataContent[i].book.category.cname == "Study Guides") {
            document.querySelector("#StudyGuides .row").appendChild(div);
          } else if (
            jsonDataContent[i].book.category.cname == "Literature & Fiction"
          ) {
            document.querySelector("#Literature .row").appendChild(div);
          } else if (
            jsonDataContent[i].book.category.cname == "Comics & Graphic Novels"
          ) {
            document.querySelector("#Comics .row").appendChild(div);
          } else if (jsonDataContent[i].book.category.cname == "General") {
            document.querySelector("#General .row").appendChild(div);
          }
        }
      }
    } else {
      console.log("No data returned from server");
    }
  })
  .catch((error) => {
    console.error("Error:", error);
  });

fetch("/book/getRecentBook", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
})
  .then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    return response.text();
  })
  .then((data) => {
    if (data) {
      var jsonData = JSON.parse(data);
      if (jsonData) {
        // Get the div with the class "row" inside the div with the class "product-list"
        let rowDiv = document.querySelector(".product-list .row");

        // Loop over the JSON data
        for (let i = 0; i < jsonData.length; i++) {
          let item = jsonData[i];

          // Create a new div element
          let div = document.createElement("div");
          div.className = "col-md-3";

          // Create the product item
          let productItem = document.createElement("div");
          productItem.className = "product-item";
          productItem.style.alignContent = "center";

          // Create the figure
          let figure = document.createElement("figure");
          figure.className = "product-style";
          figure.style.width = "auto";
          figure.style.height = "318px";
          figure.style.alignContent = "center";

          // Create the image
          let img = document.createElement("img");
          img.src = "data:image/jpeg;base64," + jsonData[i].pictures[0].picture;
          img.alt = "Books";
          img.className = "product-item";
          img.style.maxWidth = "300px";
          img.style.maxHeight = "318px";

          var a = document.createElement("a");
          a.href = "BookDetail.html?BookID=" + jsonData[i].book.bookID;
          // Create the button
          let button = document.createElement("button");
          button.type = "button";
          button.className = "add-to-cart login-registerpopup";
          button.dataset.productTile = "add-to-cart";
          button.textContent = "Detail";

          // Append the 'button' to the 'a' element
          a.appendChild(button);

          // Append the image and button to the figure
          figure.appendChild(img);
          figure.appendChild(a);

          // Append the figure to the product item
          productItem.appendChild(figure);

          // Create the figcaption
          let figcaption = document.createElement("figcaption");

          // Create the h3
          let h3 = document.createElement("h3");
          h3.textContent = jsonData[i].book.bname;

          var authors = "";

          for (var j = 0; j < jsonData[i].authors.length; j++) {
            // Add each author to the string, separated by a comma and a space
            authors += jsonData[i].authors[j].author;
            if (j < jsonData[i].authors.length - 1) {
              authors += ", ";
            }
          }
          // Create the span
          let span = document.createElement("span");
          span.textContent = authors;

          // Create the price div
          let priceDiv = document.createElement("div");
          priceDiv.className = "item-price";
          priceDiv.textContent =
            jsonData[i].book.rentPricePerDay +
            "฿ / 1 day (มัดจำ " +
            jsonData[i].book.securityDeposit +
            "฿)";

          // Append the h3, span, and price div to the figcaption
          figcaption.appendChild(h3);
          figcaption.appendChild(span);
          figcaption.appendChild(priceDiv);

          // Append the figcaption to the product item
          productItem.appendChild(figcaption);

          // Append the product item to the div
          div.appendChild(productItem);

          // Finally, append the div to the row div
          rowDiv.appendChild(div);
        }
      }
    } else {
      console.log("No data returned from server");
    }
  })
  .catch((error) => {
    console.error("Error:", error);
  });
