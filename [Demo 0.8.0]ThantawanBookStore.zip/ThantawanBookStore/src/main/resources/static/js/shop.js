fetch("/book/getAllBook", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
})
  .then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    return response.text();
  })
  .then((data) => {
    if (data) {
      var jsonDataContent = JSON.parse(data);
      let count = 0;
      if (jsonDataContent) {
        for (let i = 0; i < jsonDataContent.length; i++) {
          // Create a new div element
          let div = document.createElement("div");
          div.className = "col-md-3";

          // Create the product item
          let productItem = document.createElement("div");
          productItem.className = "product-item";
          productItem.style.alignContent = "center";

          // Create the figure
          let figure = document.createElement("figure");
          figure.className = "product-style";
          figure.style.width = "auto";
          figure.style.height = "412px";
          figure.style.alignContent = "center";

          // Create the image
          let img = document.createElement("img");
          img.src =
            "data:image/jpeg;base64," + jsonDataContent[i].pictures[0].picture;
          img.alt = "Books";
          img.className = "product-item";
          img.style.maxWidth = "300px";
          img.style.maxHeight = "412px";

          var a = document.createElement("a");
          a.href = "BookDetail.html?BookID=" + jsonDataContent[i].book.bookID;
          // Create the button
          let button = document.createElement("button");
          button.type = "button";
          button.className = "add-to-cart login-registerpopup";
          button.dataset.productTile = "add-to-cart";
          button.textContent = "Detail";

          // Append the 'button' to the 'a' element
          a.appendChild(button);

          // Append the image and button to the figure
          figure.appendChild(img);
          figure.appendChild(a);

          // Append the figure to the product item
          productItem.appendChild(figure);

          // Create the figcaption
          let figcaption = document.createElement("figcaption");

          // Create the h3
          let h3 = document.createElement("h3");
          h3.textContent = jsonDataContent[i].book.bname;

          var authors = "";

          for (var j = 0; j < jsonDataContent[i].authors.length; j++) {
            // Add each author to the string, separated by a comma and a space
            authors += jsonDataContent[i].authors[j].author;
            if (j < jsonDataContent[i].authors.length - 1) {
              authors += ", ";
            }
          }
          // Create the span
          let span = document.createElement("span");
          span.textContent = authors;

          // Create the price div
          let priceDiv = document.createElement("div");
          priceDiv.className = "item-price";
          priceDiv.textContent =
            jsonDataContent[i].book.rentPricePerDay +
            "฿ / 1 day (มัดจำ " +
            jsonDataContent[i].book.securityDeposit +
            "฿)";

          // Append the h3, span, and price div to the figcaption
          figcaption.appendChild(h3);
          figcaption.appendChild(span);
          figcaption.appendChild(priceDiv);

          // Append the figcaption to the product item
          productItem.appendChild(figcaption);

          // Append the product item to the div
          div.appendChild(productItem);

          if (i % 8 == 0) {
            count++;
            // Get the element using its data-tab-target attribute
            let li = document.querySelector(
              'li[data-tab-target="#pg' + count + '"]'
            );

            // Change the display style to 'list-item'
            li.style.display = "list-item";
          }

          let selector = `#pg${count} .row`;
          // Finally, append the div to the row div
          document.querySelector(selector).appendChild(div);
        }
      }
    } else {
      console.log("No data returned from server");
    }
  })
  .catch((error) => {
    console.error("Error:", error);
  });
