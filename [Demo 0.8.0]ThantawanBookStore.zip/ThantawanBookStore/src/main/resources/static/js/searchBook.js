let allBooks = []; // Store all books here after the initial fetch request

window.onload = function() {
  let checkboxes = document.querySelectorAll('input[name="book_choice"]');
  checkboxes.forEach(checkbox => checkbox.checked = false);
  // Set "ALL_Genre" as default checked
  document.getElementById('all_genre').checked = true;
}


fetch("/book/searchBookByName", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ bookJson: bookName }),
})
  .then((response) => {
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    return response.text();
  })
  .then((data) => {
    if (data) {
      var jsonData = JSON.parse(data);
      if (jsonData) {
        allBooks = jsonData; // Store all books
        for (let i = 0; i < jsonData.length; i++) {
          // Create a new div element
          let rowDiv = document.createElement("div");
          rowDiv.className = "row mt-3";
          rowDiv.style.backgroundColor = "#f1c8c8";

          // Create the first column
          let firstColDiv = document.createElement("div");
          firstColDiv.className =
            "col-md-3 d-flex align-items-center justify-content-center";
          firstColDiv.style.textAlign = "center";

          // Create the product item
          let productItemDiv = document.createElement("div");
          productItemDiv.className =
            "product-item d-flex flex-column align-items-center";

          // Create the figure
          let figure = document.createElement("figure");
          figure.className = "product-style";
          figure.style.margin = "20px 0 20px 0";

          // Create the image
          let img = document.createElement("img");
          img.src = "data:image/jpeg;base64," + jsonData[i].pictures[0].picture;
          img.alt = "Books";
          img.className = "product-item";
          img.style.padding = "5%";

          // Create the button
          let button = document.createElement("button");
          button.type = "button";
          button.className = "add-to-cart";
          button.dataset.productTile = "add-to-cart";
          button.textContent = "Buy now";

          // Append the image and button to the figure
          figure.appendChild(img);
          figure.appendChild(button);

          // Append the figure to the product item
          productItemDiv.appendChild(figure);

          // Append the product item to the first column
          firstColDiv.appendChild(productItemDiv);

          // Append the first column to the row
          rowDiv.appendChild(firstColDiv);

          // Create the second column
          let secondColDiv = document.createElement("div");
          secondColDiv.className =
            "col-md-9 d-flex align-items-center justify-content-center";
          secondColDiv.style.textAlign = "center";

          // Create the link
          let link = document.createElement("a");
          link.href = "BookDetail.html?BookID=" + jsonData[i].book.bookID;

          // Create the inner div
          let innerDiv = document.createElement("div");
          innerDiv.className = "col-md-12";
          innerDiv.style.textAlign = "center";
          innerDiv.style.margin = "2.5em 0";

          // Create the h2
          let h2 = document.createElement("h2");
          h2.style.marginBottom = "15px";
          h2.style.marginTop = "0";
          h2.textContent = jsonData[i].book.bname;

          // Create the h4
          let h4 = document.createElement("h4");
          h4.textContent = jsonData[i].book.tagline;

          // Initialize an empty string for the authors
          var authors = "";

          for (var j = 0; j < jsonData[i].authors.length; j++) {
            // Add each author to the string, separated by a comma and a space
            authors += jsonData[i].authors[j].author;
            if (j < jsonData[i].authors.length - 1) {
              authors += ", ";
            }
          }

          // Create the span
          let span = document.createElement("span");
          span.textContent = authors;

          // Create the price div
          let priceDiv = document.createElement("div");
          priceDiv.className = "item-price";
          priceDiv.textContent =
            jsonData[i].book.rentPricePerDay +
            "฿ / 1 day (มัดจำ " +
            jsonData[i].book.securityDeposit +
            "฿)";

          // Append the h2, h4, span, and price div to the inner div
          innerDiv.appendChild(h2);
          innerDiv.appendChild(h4);
          innerDiv.appendChild(span);
          innerDiv.appendChild(priceDiv);

          // Append the inner div to the link
          link.appendChild(innerDiv);

          // Append the link to the second column
          secondColDiv.appendChild(link);

          // Append the second column to the row
          rowDiv.appendChild(secondColDiv);

          // Get the div with the class "row"
          let rowContainer = document.querySelector(".searchResult");

          // Append rowDiv to the rowContainer
          rowContainer.appendChild(rowDiv);
        }
      }
    } else {
      console.log("No data returned from server");
    }
  })
  .catch((error) => {
    console.error("Error:", error);
  });

function displayBooks(books, selectedCategories) {
  // Get the div where the books should be displayed
  let rowContainer = document.querySelector(".searchResult");

  // Clear any existing books
  rowContainer.innerHTML = "";

  let filteredBooks = books;
  if (!selectedCategories.includes("ALL_Genre") || selectedCategories.length > 1) {
    filteredBooks = books.filter(
      ({
        book: {
          category: { cname },
        },
      }) => selectedCategories.includes(cname)
    );
  }

  // Loop over the books and create HTML elements for each one
  for (let i = 0; i < filteredBooks.length; i++) {
    // Create a new div element
    let rowDiv = document.createElement("div");
    rowDiv.className = "row mt-3";
    rowDiv.style.backgroundColor = "#f1c8c8";

    // Create the first column
    let firstColDiv = document.createElement("div");
    firstColDiv.className =
      "col-md-3 d-flex align-items-center justify-content-center";
    firstColDiv.style.textAlign = "center";

    // Create the product item
    let productItemDiv = document.createElement("div");
    productItemDiv.className =
      "product-item d-flex flex-column align-items-center";

    // Create the figure
    let figure = document.createElement("figure");
    figure.className = "product-style";
    figure.style.margin = "20px 0 20px 0";

    // Create the image
    let img = document.createElement("img");
    img.src = "data:image/jpeg;base64," + filteredBooks[i].pictures[0].picture;
    img.alt = "Books";
    img.className = "product-item";
    img.style.padding = "5%";

    // Create the button
    let button = document.createElement("button");
    button.type = "button";
    button.className = "add-to-cart";
    button.dataset.productTile = "add-to-cart";
    button.textContent = "Buy now";

    // Append the image and button to the figure
    figure.appendChild(img);
    figure.appendChild(button);

    // Append the figure to the product item
    productItemDiv.appendChild(figure);

    // Append the product item to the first column
    firstColDiv.appendChild(productItemDiv);

    // Append the first column to the row
    rowDiv.appendChild(firstColDiv);

    // Create the second column
    let secondColDiv = document.createElement("div");
    secondColDiv.className =
      "col-md-9 d-flex align-items-center justify-content-center";
    secondColDiv.style.textAlign = "center";

    // Create the link
    let link = document.createElement("a");
    link.href = "BookDetail.html?BookID=" + filteredBooks[i].book.bookID;

    // Create the inner div
    let innerDiv = document.createElement("div");
    innerDiv.className = "col-md-12";
    innerDiv.style.textAlign = "center";
    innerDiv.style.margin = "2.5em 0";

    // Create the h2
    let h2 = document.createElement("h2");
    h2.style.marginBottom = "15px";
    h2.style.marginTop = "0";
    h2.textContent = filteredBooks[i].book.bname;

    // Create the h4
    let h4 = document.createElement("h4");
    h4.textContent = filteredBooks[i].book.tagline;

    // Initialize an empty string for the authors
    var authors = "";

    for (var j = 0; j < filteredBooks[i].authors.length; j++) {
      // Add each author to the string, separated by a comma and a space
      authors += filteredBooks[i].authors[j].author;
      if (j < filteredBooks[i].authors.length - 1) {
        authors += ", ";
      }
    }

    // Create the span
    let span = document.createElement("span");
    span.textContent = authors;

    // Create the price div
    let priceDiv = document.createElement("div");
    priceDiv.className = "item-price";
    priceDiv.textContent =
      filteredBooks[i].book.rentPricePerDay +
      "฿ / 1 day (มัดจำ " +
      filteredBooks[i].book.securityDeposit +
      "฿)";

    // Append the h2, h4, span, and price div to the inner div
    innerDiv.appendChild(h2);
    innerDiv.appendChild(h4);
    innerDiv.appendChild(span);
    innerDiv.appendChild(priceDiv);

    // Append the inner div to the link
    link.appendChild(innerDiv);

    // Append the link to the second column
    secondColDiv.appendChild(link);

    // Append the second column to the row
    rowDiv.appendChild(secondColDiv);

    // Get the div with the class "row"
    let rowContainer = document.querySelector(".searchResult");

    // Append rowDiv to the rowContainer
    rowContainer.appendChild(rowDiv);
  }
}

function filterBooks() {
  let checkboxes = document.querySelectorAll(
    'input[name="book_choice"]:checked'
  );
  let selectedValues = Array.from(checkboxes).map((checkbox) => checkbox.value);
  displayBooks(allBooks, selectedValues);
}
