package com.thantawan.ThantawanBookStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThantawanBookStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThantawanBookStoreApplication.class, args);
	}

}
