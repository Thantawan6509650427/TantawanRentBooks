package com.thantawan.ThantawanBookStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThantawanBookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
